#!/usr/bin/env python3
"""
MyProject - Main Application Entry Point
"""
import logging
import os
from datetime import datetime

from flask import Flask, jsonify, request
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_cors import CORS

app = Flask(__name__)

# Initialize extensions
jwt = JWTManager(app)
cors = CORS(app)

logger = logging.getLogger(__name__)


@app.route('/')
def index():
    """API root endpoint"""
    return jsonify({
        "service": "MyProject API",
        "version": "2.1.0",
        "timestamp": datetime.utcnow().isoformat(),
        "endpoints": {
            "authentication": "/auth",
            "users": "/api/users", 
            "data": "/api/data",
            "health": "/health",
            "docs": "/docs"
        }
    })


@app.route('/health')
def health_check():
    """Service health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "components": {
            "database": "up",
            "redis": "up",
            "api": "up"
        }
    })


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_ENV') == 'development'
    
    logger.info(f"Starting MyProject API on port {port} (debug={debug})")
    app.run(host='0.0.0.0', port=port, debug=debug)
